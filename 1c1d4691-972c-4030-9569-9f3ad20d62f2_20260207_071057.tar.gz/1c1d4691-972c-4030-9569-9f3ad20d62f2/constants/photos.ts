// Photo references for Divita's scrapbook
// These map to the photos provided by the user
// Photos are organized by scrapbook section

export interface PhotoItem {
  id: string;
  source: any;
  caption: string;
  section: string;
  rotation?: number;
  washiTapeColor?: string;
}

// Import all photos
const photo1 = require('@/assets/images/divita/photo1.jpg');
const photo2 = require('@/assets/images/divita/photo2.jpg');
const photo3 = require('@/assets/images/divita/photo3.jpg');
const photo4 = require('@/assets/images/divita/photo4.jpg');
const photo5 = require('@/assets/images/divita/photo5.jpg');
const photo6 = require('@/assets/images/divita/photo6.jpg');
const photo7 = require('@/assets/images/divita/photo7.jpg');
const photo8 = require('@/assets/images/divita/photo8.jpg');
const photo9 = require('@/assets/images/divita/photo9.jpg');

export const scrapbookPhotos: PhotoItem[] = [
  // Soft & Aesthetic
  {
    id: 'soft1',
    source: photo2,
    caption: 'Dreamy vibes only ✨',
    section: 'soft',
    rotation: -2,
    washiTapeColor: '#F8C8DC',
  },
  {
    id: 'soft2',
    source: photo4,
    caption: 'Soft & stunning 🌸',
    section: 'soft',
    rotation: 3,
    washiTapeColor: '#D4B8E0',
  },
  // Happy & Smiley
  {
    id: 'happy1',
    source: photo5,
    caption: 'That smile though! 😊',
    section: 'happy',
    rotation: -1,
    washiTapeColor: '#FFD700',
  },
  {
    id: 'happy2',
    source: photo6,
    caption: 'Pure sunshine 🌞',
    section: 'happy',
    rotation: 2,
    washiTapeColor: '#FFDAB9',
  },
  // Goofy & Fun
  {
    id: 'goofy1',
    source: photo9,
    caption: 'Being goofy & gorgeous 🤪',
    section: 'goofy',
    rotation: -3,
    washiTapeColor: '#D6E6F2',
  },
  // Strong & Confident
  {
    id: 'strong1',
    source: photo3,
    caption: 'Boss energy 💪✨',
    section: 'strong',
    rotation: 1,
    washiTapeColor: '#D4B8E0',
  },
  {
    id: 'strong2',
    source: photo8,
    caption: 'Confidence looks beautiful on you 💖',
    section: 'strong',
    rotation: -2,
    washiTapeColor: '#F0D9B5',
  },
  // Golden Memories
  {
    id: 'golden1',
    source: photo1,
    caption: 'Golden hour magic ✨',
    section: 'golden',
    rotation: 2,
    washiTapeColor: '#F0D9B5',
  },
  {
    id: 'golden2',
    source: photo7,
    caption: 'Making memories 💫',
    section: 'golden',
    rotation: -1,
    washiTapeColor: '#FFDAB9',
  },
];
