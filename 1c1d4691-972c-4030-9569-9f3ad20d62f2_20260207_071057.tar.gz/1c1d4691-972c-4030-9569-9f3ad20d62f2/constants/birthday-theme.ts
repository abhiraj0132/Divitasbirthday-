export const BirthdayColors = {
  blushPink: '#F8C8DC',
  deepPink: '#E8829A',
  lavender: '#D4B8E0',
  softLavender: '#EDE0F0',
  peach: '#FFDAB9',
  cream: '#FFF8F0',
  warmCream: '#FFF5E6',
  gold: '#D4A574',
  softGold: '#F0D9B5',
  white: '#FFFFFF',
  roseGold: '#B76E79',
  softRose: '#F5E1E6',
  babyBlue: '#D6E6F2',
  mintGreen: '#D4EFDF',
  warmGray: '#9B8E8E',
  textDark: '#4A3B3B',
  textMedium: '#6B5B5B',
  textLight: '#8B7B7B',
  cardShadow: 'rgba(184, 110, 121, 0.15)',
  overlay: 'rgba(248, 200, 220, 0.3)',
  gradientStart: '#FFF0F5',
  gradientMiddle: '#F8E8F0',
  gradientEnd: '#EDE0F0',
  confettiPink: '#FF69B4',
  confettiGold: '#FFD700',
  confettiLavender: '#B19CD9',
  confettiPeach: '#FFDAB9',
  heartRed: '#FF6B8A',
  sparkle: '#FFE4B5',
};

export const BirthdayFonts = {
  handwritten: 'DancingScript_700Bold',
  handwrittenRegular: 'DancingScript_400Regular',
  elegant: 'PlayfairDisplay_700Bold',
  elegantItalic: 'PlayfairDisplay_700Bold_Italic',
  body: 'Poppins_400Regular',
  bodyMedium: 'Poppins_500Medium',
  bodySemiBold: 'Poppins_600SemiBold',
  bodyBold: 'Poppins_700Bold',
  script: 'Sacramento_400Regular',
};

export const BirthdayShadow = {
  shadowColor: BirthdayColors.roseGold,
  shadowOffset: { width: 0, height: 4 },
  shadowOpacity: 0.15,
  shadowRadius: 12,
  elevation: 6,
};

export const BirthdayCardStyle = {
  backgroundColor: BirthdayColors.white,
  borderRadius: 20,
  padding: 20,
  ...BirthdayShadow,
};

export const WashiTapeColors = [
  '#F8C8DC',
  '#D4B8E0',
  '#FFDAB9',
  '#D6E6F2',
  '#D4EFDF',
  '#F0D9B5',
  '#F5E1E6',
];

export const ScrapbookSections = [
  { id: 'soft', title: 'Soft & Aesthetic', emoji: '🌸', color: '#F8C8DC' },
  { id: 'happy', title: 'Happy & Smiley', emoji: '😊', color: '#FFD700' },
  { id: 'goofy', title: 'Goofy & Fun', emoji: '🤪', color: '#FFDAB9' },
  { id: 'strong', title: 'Strong & Confident', emoji: '💪', color: '#D4B8E0' },
  { id: 'golden', title: 'Golden Memories', emoji: '✨', color: '#F0D9B5' },
  { id: 'birthday', title: 'Birthday Special', emoji: '🎂', color: '#FF69B4' },
];

export const QuizQuestions = [
  {
    question: 'What is your ideal way to spend a birthday?',
    options: [
      'A cozy day with close friends',
      'A grand party with everyone',
      'A solo self-care day',
      'An adventure trip',
    ],
    feedback: [
      'You value deep connections! 💕',
      'Life of the party! 🎉',
      'Self-love queen! 👑',
      'Adventure awaits you! 🌟',
    ],
  },
  {
    question: 'Pick your comfort color:',
    options: ['Blush Pink 🌸', 'Lavender 💜', 'Peach 🍑', 'Sky Blue 💙'],
    feedback: [
      'Romantic & dreamy soul! 🌸',
      'Calm & creative spirit! 💜',
      'Warm & cheerful heart! 🍑',
      'Peaceful & free! 💙',
    ],
  },
  {
    question: 'Your go-to pick-me-up?',
    options: ['Chocolate 🍫', 'Music 🎵', 'A good book 📚', 'A long walk 🌿'],
    feedback: [
      'Sweet tooth, sweet heart! 🍫',
      'Music heals your soul! 🎵',
      'An old soul with golden taste! 📚',
      'Nature is your therapy! 🌿',
    ],
  },
  {
    question: 'What superpower would you choose?',
    options: ['Time Travel ⏰', 'Teleportation 🌍', 'Mind Reading 🧠', 'Flying 🦋'],
    feedback: [
      'Nostalgic dreamer! ⏰',
      'Wanderlust runs in your veins! 🌍',
      'Deeply empathetic soul! 🧠',
      'Freedom is your mantra! 🦋',
    ],
  },
  {
    question: 'Your love language is:',
    options: ['Words of Affirmation 💌', 'Quality Time ⏳', 'Acts of Service 🤝', 'Gifts 🎁'],
    feedback: [
      'Words touch your heart! 💌',
      'Presence over presents! ⏳',
      'Actions speak louder! 🤝',
      'Thoughtful & appreciative! 🎁',
    ],
  },
];

export const ThisOrThatChoices = [
  { optionA: '🎬 Cozy Movie Night', optionB: '🏔️ Adventure Day' },
  { optionA: '☕ Coffee', optionB: '🍵 Chai' },
  { optionA: '🌅 Sunrise', optionB: '🌙 Sunset' },
  { optionA: '📖 Reading', optionB: '🎵 Music' },
  { optionA: '🍕 Pizza', optionB: '🍜 Noodles' },
  { optionA: '🏖️ Beach', optionB: '🏔️ Mountains' },
  { optionA: '🎨 Art', optionB: '📷 Photography' },
  { optionA: '🌸 Spring', optionB: '🍂 Autumn' },
];

export const MemoryMatchIcons = [
  '🎂', '🎀', '⭐', '🌸', '💖', '🦋', '🎁', '✨',
];

export const ReflectionQuestions = [
  { id: '1', question: 'What made you happiest this year, Divita?', emoji: '😊' },
  { id: '2', question: 'What is one thing you are proud of yourself for?', emoji: '💪' },
  { id: '3', question: 'What is a dream you want to chase this year?', emoji: '🌟' },
  { id: '4', question: 'Who made your year extra special?', emoji: '💕' },
  { id: '5', question: 'What lesson will you carry forward?', emoji: '📖' },
  { id: '6', question: 'Write a love note to yourself:', emoji: '💌' },
];

export const BirthdayLetter = `7 February

My Dearest Divita,

Happy Birthday, beautiful soul! 🎂💖

Today is YOUR day — the day the world was gifted with someone truly extraordinary. And I want you to know just how special you are.

You are the kind of person who lights up every room you walk into. Your smile? It's magic. Your laugh? It's music. Your kindness? It's a gift to everyone lucky enough to know you.

This past year, I've watched you grow in ways that made me so proud. You've faced challenges with such grace, embraced joy with such warmth, and stayed true to who you are — always gentle, always fierce, always beautifully YOU.

Divita, you deserve the world and everything beautiful in it. You deserve mornings that start with laughter, days filled with sunshine and chai, evenings wrapped in comfort and love, and nights where your dreams feel closer than ever.

On this birthday, I want you to promise me something — to love yourself a little more, to be a little kinder to yourself, and to never forget that you are enough. More than enough. You are extraordinary.

Here's to another year of adventures, inside jokes, late-night talks, and making memories that we'll laugh about for years to come.

May this year bring you everything your heart desires and so much more. May every wish you make today come true, and may you always know how deeply, fiercely, and endlessly you are loved.

Happy Birthday, my sweet Divita. This one's for you. 💗

With all the love in the world,
From Abhiraj 💕

P.S. — You're not just a year older; you're a year more incredible. Never forget that. ✨`;
