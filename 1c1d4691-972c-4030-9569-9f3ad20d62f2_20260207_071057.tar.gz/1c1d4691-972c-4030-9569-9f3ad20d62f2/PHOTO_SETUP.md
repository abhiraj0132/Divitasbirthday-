# 📸 Adding Divita's Photos to the App

## Current Status
The app structure is ready, but the photos in `/assets/images/divita/` are placeholders.

## Adding the Actual Photos

### Photos to Add (9 total):
The beautiful photos you shared should replace the placeholders in:
```
/workspace/assets/images/divita/
  ├── photo1.jpg
  ├── photo2.jpg
  ├── photo3.jpg
  ├── photo4.jpg
  ├── photo5.jpg
  ├── photo6.jpg
  ├── photo7.jpg
  ├── photo8.jpg
  └── photo9.jpg
```

### Steps to Add Photos:

#### Option 1: Via File Upload
1. Open the file manager or upload interface
2. Navigate to `/workspace/assets/images/divita/`
3. Replace each placeholder with actual photos
4. Name them: `photo1.jpg`, `photo2.jpg`, etc.

#### Option 2: Via Command Line
```bash
# If photos are in a folder called "divita_photos"
cp /path/to/divita_photos/image1.jpg /workspace/assets/images/divita/photo1.jpg
cp /path/to/divita_photos/image2.jpg /workspace/assets/images/divita/photo2.jpg
# ... and so on
```

### After Adding Photos:

#### Rebuild Web Version:
```bash
npx expo export --platform web --output-dir dist/web --clear
```

#### Rebuild Native App:
```bash
# For Android
npx eas-cli build --platform android --profile preview

# For iOS
npx eas-cli build --platform ios --profile production
```

### Photo Requirements:
- **Format**: JPG or PNG
- **Recommended Size**: 1080x1080px or similar (will be auto-scaled)
- **Max File Size**: ~5MB per photo for optimal performance
- **Aspect Ratio**: Any (app handles different ratios gracefully)

### Photo Optimization (Optional):
If photos are very large, you can optimize them:

```bash
# Install image optimization tool
npm install -g sharp-cli

# Optimize all photos
sharp -i assets/images/divita/*.jpg -o assets/images/divita/ --width 1080 --quality 85
```

## Verification

After adding photos, verify they appear correctly:

1. **Web Version**:
   ```bash
   npx expo start --web
   ```
   Navigate to Scrapbook section

2. **Mobile Preview**:
   ```bash
   npx expo start
   ```
   Scan QR with Expo Go app

---

**Note**: The app will work with placeholders, but for the full gift experience, add Divita's actual photos before final deployment! 📸✨
