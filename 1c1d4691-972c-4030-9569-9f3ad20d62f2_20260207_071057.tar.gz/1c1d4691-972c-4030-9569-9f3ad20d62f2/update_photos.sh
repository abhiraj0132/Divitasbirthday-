#!/bin/bash
# Save the user-provided images
