#!/bin/bash
echo "🎂 Testing Divita's Birthday Bloom Web App locally..."
echo ""
echo "Installing serve package..."
npm i -g serve

echo ""
echo "🚀 Starting web server..."
echo "Open your browser to: http://localhost:3000"
echo "Test on your phone: http://[YOUR_LOCAL_IP]:3000"
echo ""
echo "Press Ctrl+C to stop the server"
echo ""

serve dist-web -p 3000
