import AsyncStorage from '@react-native-async-storage/async-storage';

export interface UploadedPhoto {
  uri: string;
  caption?: string;
  rotation?: number;
  washiTapeColor?: string;
}

export interface UserPhotos {
  [sectionId: string]: UploadedPhoto[];
}

const STORAGE_KEY = '@divita_scrapbook_photos';

/**
 * Save photos for a specific section
 */
export async function saveSectionPhotos(
  sectionId: string,
  photos: UploadedPhoto[]
): Promise<void> {
  try {
    const allPhotos = await getAllUserPhotos();
    allPhotos[sectionId] = photos;
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(allPhotos));
  } catch (error) {
    console.error('Error saving section photos:', error);
    throw error;
  }
}

/**
 * Get photos for a specific section
 */
export async function getSectionPhotos(
  sectionId: string
): Promise<UploadedPhoto[]> {
  try {
    const allPhotos = await getAllUserPhotos();
    return allPhotos[sectionId] || [];
  } catch (error) {
    console.error('Error getting section photos:', error);
    return [];
  }
}

/**
 * Get all user photos
 */
export async function getAllUserPhotos(): Promise<UserPhotos> {
  try {
    const data = await AsyncStorage.getItem(STORAGE_KEY);
    return data ? JSON.parse(data) : {};
  } catch (error) {
    console.error('Error getting all user photos:', error);
    return {};
  }
}

/**
 * Delete a photo from a section
 */
export async function deletePhotoFromSection(
  sectionId: string,
  photoIndex: number
): Promise<void> {
  try {
    const allPhotos = await getAllUserPhotos();
    const sectionPhotos = allPhotos[sectionId] || [];
    sectionPhotos.splice(photoIndex, 1);
    allPhotos[sectionId] = sectionPhotos;
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(allPhotos));
  } catch (error) {
    console.error('Error deleting photo:', error);
    throw error;
  }
}

/**
 * Clear all photos
 */
export async function clearAllPhotos(): Promise<void> {
  try {
    await AsyncStorage.removeItem(STORAGE_KEY);
  } catch (error) {
    console.error('Error clearing all photos:', error);
    throw error;
  }
}

/**
 * Check if section has user photos
 */
export async function hasSectionPhotos(sectionId: string): Promise<boolean> {
  try {
    const photos = await getSectionPhotos(sectionId);
    return photos.length > 0;
  } catch (error) {
    console.error('Error checking section photos:', error);
    return false;
  }
}
