#!/bin/bash

# Quick deployment script for Divita's Birthday Bloom
echo "🎂 Divita's Birthday Bloom - Quick Deploy Script"
echo "================================================"
echo ""

# Check if dist exists
if [ ! -d "/workspace/dist" ]; then
    echo "❌ Web build not found. Building now..."
    npx expo export --platform web
else
    echo "✅ Web build found in /workspace/dist"
fi

echo ""
echo "📦 Deployment Options:"
echo ""
echo "1. Netlify (Recommended):"
echo "   npm install -g netlify-cli"
echo "   netlify deploy --dir=dist --prod"
echo ""
echo "2. Vercel:"
echo "   npm install -g vercel"
echo "   cd dist && vercel --prod"
echo ""
echo "3. GitHub Pages:"
echo "   - Push dist contents to gh-pages branch"
echo "   - Enable GitHub Pages in repo settings"
echo ""
echo "4. Firebase Hosting:"
echo "   npm install -g firebase-tools"
echo "   firebase login"
echo "   firebase init hosting"
echo "   firebase deploy"
echo ""
echo "💡 For Android APK:"
echo "   npx eas-cli login"
echo "   npx eas-cli build --platform android --profile production"
echo ""
echo "🎉 Choose your deployment method and follow the instructions!"
