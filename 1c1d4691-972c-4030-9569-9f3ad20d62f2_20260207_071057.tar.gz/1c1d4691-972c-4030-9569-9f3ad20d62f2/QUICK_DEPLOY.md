# ⚡ Quick Deploy Guide - Get App to Divita in 5 Minutes!

## 🎯 Fastest Path to Deployment

### Method 1: Android APK (Recommended) - ~15 minutes
**Best for**: Direct installation on any Android phone

```bash
# Step 1: Login (one-time setup)
npx eas-cli login

# Step 2: Build APK
npx eas-cli build --platform android --profile preview

# Step 3: Wait for build (~15 min)
# You'll receive email + dashboard notification when ready

# Step 4: Get link and share!
```

**What Divita does:**
1. Click the link you send
2. Download APK file
3. Open file to install
4. Done! App is on her phone forever 🎉

---

### Method 2: Web App (Instant) - ~2 minutes
**Best for**: Works on ANY device (iPhone, Android, Computer)

```bash
# Option A: Netlify (Easiest)
npm install -g netlify-cli
cd dist/web
netlify deploy --prod

# Option B: Vercel
npm install -g vercel
cd dist/web
vercel --prod
```

**What Divita does:**
1. Click the link you send
2. Opens in browser
3. Tap "Add to Home Screen"
4. Works like native app! 📱

---

## 📱 Sending to Divita

### Message Template:
```
🎉 Happy Birthday Divita! 🎂

I made something special just for you...
A personalized birthday app! 💝

👉 [INSERT YOUR LINK HERE]

[For Android APK:]
Download it, open the file, and tap Install!

[For Web App:]
Open it and tap "Add to Home Screen"!

Love you! ✨
```

---

## 🎁 What Divita Will See

1. **Beautiful splash screen** with her name
2. **Home screen** with countdown timer
3. **7 sections** to explore:
   - Games
   - Reflections
   - Quotes
   - Scrapbook (with photos)
   - Gifts
   - Final Message
4. **Premium design** throughout

---

## ⚡ Commands Cheat Sheet

```bash
# Check build status
npx eas-cli build:list

# View builds in browser
npx eas-cli build:view

# Cancel a build
npx eas-cli build:cancel

# Re-deploy web
cd dist/web && netlify deploy --prod
```

---

## 🆘 Quick Troubleshooting

**Build taking long?**
→ Normal! Android: 10-15 min, iOS: 15-20 min

**EAS login not working?**
→ Create account at expo.dev first, then login

**APK won't install?**
→ Enable "Install from Unknown Sources" in Android settings

**Web link not working?**
→ Check if you ran `netlify deploy --prod` (not `--draft`)

---

## ✅ You're Done When...

✅ You have a shareable link (web URL or APK download link)
✅ Link works when you test it
✅ You've sent it to Divita
✅ She has the app on her phone!

---

**That's it! Choose a method, run the commands, share the link! 🚀**

*The hard work is done - everything is ready to deploy!*
