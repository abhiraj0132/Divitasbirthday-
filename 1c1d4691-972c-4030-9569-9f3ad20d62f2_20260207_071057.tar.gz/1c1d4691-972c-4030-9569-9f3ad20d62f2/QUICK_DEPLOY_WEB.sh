#!/bin/bash

# 🎁 Quick Web Deployment Script for Divita's Birthday Bloom
# This script helps you deploy the web version instantly

set -e

echo "╔═══════════════════════════════════════════════════════════╗"
echo "║  🎉 DIVITA'S BIRTHDAY BLOOM - WEB DEPLOYMENT 🎉          ║"
echo "╚═══════════════════════════════════════════════════════════╝"
echo ""

# Check if photos have been replaced
echo "📸 Checking if photos are integrated..."
PHOTO_SIZE=$(stat -c%s /workspace/assets/images/divita/photo1.jpg 2>/dev/null || stat -f%z /workspace/assets/images/divita/photo1.jpg 2>/dev/null)

if [ "$PHOTO_SIZE" -lt 5000 ]; then
    echo "⚠️  WARNING: Photos appear to be placeholders (${PHOTO_SIZE} bytes)"
    echo ""
    echo "For the best experience, please integrate the 9 photos first:"
    echo "  1. Save the 9 photos from the conversation"
    echo "  2. Rename them as photo1.jpg through photo9.jpg"
    echo "  3. Copy them to /workspace/assets/images/divita/"
    echo "  4. Run: npx expo export --platform web"
    echo ""
    echo "Then run this script again!"
    echo ""
    read -p "Continue with deployment anyway? (y/N): " -n 1 -r
    echo ""
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
fi

echo "✅ Ready to deploy!"
echo ""
echo "🚀 Choose your deployment platform:"
echo ""
echo "  1) Vercel (Recommended) - Fast, reliable, FREE"
echo "  2) Netlify - Great performance, FREE"
echo "  3) Surge - Simplest option, FREE"
echo ""
read -p "Enter choice (1-3): " choice
echo ""

case $choice in
    1)
        echo "🌐 Deploying to Vercel..."
        echo ""
        echo "Running: npx vercel dist --prod"
        echo ""
        npx vercel dist --prod
        echo ""
        echo "✅ Deployed to Vercel!"
        echo ""
        echo "🎊 Your shareable URL will be shown above"
        echo "   Format: https://[project-name].vercel.app"
        ;;
    2)
        echo "🌐 Deploying to Netlify..."
        echo ""
        echo "Running: npx netlify-cli deploy --dir=dist --prod"
        echo ""
        npx netlify-cli deploy --dir=dist --prod
        echo ""
        echo "✅ Deployed to Netlify!"
        echo ""
        echo "🎊 Your shareable URL will be shown above"
        echo "   Format: https://[project-name].netlify.app"
        ;;
    3)
        echo "🌐 Deploying to Surge..."
        echo ""
        PROJECT_NAME="divitas-birthday-bloom-${RANDOM}"
        echo "Running: npx surge dist ${PROJECT_NAME}.surge.sh"
        echo ""
        cd dist
        npx surge . ${PROJECT_NAME}.surge.sh
        cd ..
        echo ""
        echo "✅ Deployed to Surge!"
        echo ""
        echo "🎊 Your shareable URL: https://${PROJECT_NAME}.surge.sh"
        ;;
    *)
        echo "❌ Invalid choice. Please run the script again."
        exit 1
        ;;
esac

echo ""
echo "╔═══════════════════════════════════════════════════════════╗"
echo "║  ✨ WEB VERSION DEPLOYED SUCCESSFULLY! ✨                 ║"
echo "╚═══════════════════════════════════════════════════════════╝"
echo ""
echo "📱 Share this link with Divita!"
echo ""
echo "🎁 The web app includes:"
echo "   ✅ Interactive scrapbook with 9 photos"
echo "   ✅ Personality quiz"
echo "   ✅ This or That game"
echo "   ✅ Memory match game"
echo "   ✅ Gift boxes"
echo "   ✅ Personal letter from Abhiraj"
echo "   ✅ Final heartfelt message"
echo ""
echo "💝 Made with love for Divita's Birthday"
echo ""
