# 📱 Build Android APK for Divita's Birthday Bloom

## Prerequisites
- Expo account (free): https://expo.dev/signup
- EAS CLI installed (already done in this project)

## Quick Build Steps

### Step 1: Login to EAS (One-time setup)
```bash
npx eas-cli login
```
Enter your Expo credentials when prompted.

### Step 2: Build the APK
```bash
npx eas-cli build --platform android --profile production
```

**What happens:**
- Build starts on Expo's cloud servers (no local Android setup needed!)
- Takes ~10-15 minutes
- You'll get a download link when complete

### Step 3: Download & Share
Once the build completes, you'll get:
- **Download URL** for the APK file
- **QR Code** for easy download on Android devices

## Alternative: Build Locally (Advanced)

If you prefer to build locally without Expo servers:

```bash
# Install dependencies
npx expo install

# Generate Android project
npx expo prebuild --platform android

# Build APK locally (requires Android SDK)
cd android
./gradlew assembleRelease

# APK location:
# android/app/build/outputs/apk/release/app-release.apk
```

## Testing the APK

### On Physical Device:
1. Transfer APK to Android device
2. Enable "Install from Unknown Sources"
3. Open APK file to install
4. Launch "Divita's Birthday Bloom"

### On Emulator:
```bash
npx expo run:android --variant release
```

## Sharing the APK with Divita

### Option 1: Direct Download Link
After EAS build completes, you get a shareable URL:
```
https://expo.dev/artifacts/eas/[BUILD-ID].apk
```

### Option 2: Upload to Drive/Dropbox
1. Download APK from EAS
2. Upload to Google Drive or Dropbox
3. Share link with Divita

### Option 3: Transfer Directly
- AirDrop (if using Mac with Android nearby)
- USB transfer
- Email attachment (if under 25MB)

## Build Status & Monitoring

Check build status anytime:
```bash
npx eas-cli build:list
```

Or visit: https://expo.dev/accounts/abhiraj0132/projects/divitas-birthday-bloom/builds

## APK Details

- **Package Name**: `com.divita.birthdaybloom`
- **Version**: 1.0.0
- **Build Profile**: Production (optimized & signed)
- **Size**: ~50-60 MB (estimated)

## Troubleshooting

### "Build failed" error
```bash
# View build logs
npx eas-cli build:view [BUILD-ID]
```

### "Keystore not found"
```bash
# Generate new keystore (automatic)
npx eas-cli credentials
```

---

## 🎁 What's Included in the APK

✅ **9-Photo Scrapbook** with themed sections
✅ **3 Interactive Games**:
   - Personality Quiz
   - Memory Match Game
   - This or That
✅ **Reflection Journal** for meaningful thoughts
✅ **3 Animated Gift Boxes** to unwrap
✅ **Heartfelt Letter** signed "From Abhiraj"
✅ **Premium Design** with Blush Pink, Lavender & Gold theme
✅ **Smooth Animations** throughout
✅ **Photo Management** feature built-in

---

**Quick Command Reference:**
```bash
# Build APK
npx eas-cli build -p android --profile production

# Check build status
npx eas-cli build:list

# Download APK directly
npx eas-cli build:download --latest
```
