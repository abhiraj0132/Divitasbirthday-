import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Animated,
  Dimensions,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { BirthdayColors, BirthdayFonts, BirthdayShadow } from '@/constants/birthday-theme';

const { width: SCREEN_WIDTH } = Dimensions.get('window');

interface TimeLeft {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
}

interface CountdownTimerProps {
  targetDate?: Date;
}

export default function CountdownTimer({ targetDate }: CountdownTimerProps) {
  const [timeLeft, setTimeLeft] = useState<TimeLeft>({ days: 0, hours: 0, minutes: 0, seconds: 0 });
  const [isBirthday, setIsBirthday] = useState(false);

  // Animated values for each digit
  const daysAnim = useRef(new Animated.Value(0)).current;
  const hoursAnim = useRef(new Animated.Value(0)).current;
  const minutesAnim = useRef(new Animated.Value(0)).current;
  const secondsAnim = useRef(new Animated.Value(0)).current;

  // Sparkle animation
  const sparkleAnim = useRef(new Animated.Value(0)).current;
  const sparkleRotate = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    // Target date: February 7th of the current year (or next year if already passed)
    const getTargetDateFn = () => {
      if (targetDate) return targetDate;
      const now = new Date();
      const currentYear = now.getFullYear();
      const target = new Date(currentYear, 1, 7, 0, 0, 0); // February is month 1 (0-indexed)

      // If the date has passed this year, target next year
      if (now > target) {
        return new Date(currentYear + 1, 1, 7, 0, 0, 0);
      }
      return target;
    };

    const target = getTargetDateFn();

    const calculateTimeLeft = () => {
      const now = new Date();
      const difference = target.getTime() - now.getTime();

      // Check if it's February 7th
      if (now.getMonth() === 1 && now.getDate() === 7) {
        setIsBirthday(true);
        return;
      }

      if (difference > 0) {
        const days = Math.floor(difference / (1000 * 60 * 60 * 24));
        const hours = Math.floor((difference / (1000 * 60 * 60)) % 24);
        const minutes = Math.floor((difference / 1000 / 60) % 60);
        const seconds = Math.floor((difference / 1000) % 60);

        setTimeLeft({ days, hours, minutes, seconds });
        setIsBirthday(false);
      } else {
        setIsBirthday(true);
      }
    };

    calculateTimeLeft();
    const timer = setInterval(calculateTimeLeft, 1000);

    return () => clearInterval(timer);
  }, [targetDate]);

  // Animate number changes
  useEffect(() => {
    const animateValue = (animValue: Animated.Value) => {
      Animated.sequence([
        Animated.timing(animValue, {
          toValue: 1,
          duration: 200,
          useNativeDriver: true,
        }),
        Animated.timing(animValue, {
          toValue: 0,
          duration: 200,
          useNativeDriver: true,
        }),
      ]).start();
    };

    animateValue(secondsAnim);
  }, [timeLeft.seconds, secondsAnim]);

  // Sparkle animation for birthday message
  useEffect(() => {
    if (isBirthday) {
      Animated.loop(
        Animated.parallel([
          Animated.sequence([
            Animated.timing(sparkleAnim, {
              toValue: 1,
              duration: 1000,
              useNativeDriver: true,
            }),
            Animated.timing(sparkleAnim, {
              toValue: 0,
              duration: 1000,
              useNativeDriver: true,
            }),
          ]),
          Animated.timing(sparkleRotate, {
            toValue: 1,
            duration: 2000,
            useNativeDriver: true,
          }),
        ])
      ).start();
    }
  }, [isBirthday, sparkleAnim, sparkleRotate]);

  const sparkleScale = sparkleAnim.interpolate({
    inputRange: [0, 1],
    outputRange: [0.8, 1.2],
  });

  const sparkleRotation = sparkleRotate.interpolate({
    inputRange: [0, 1],
    outputRange: ['0deg', '360deg'],
  });

  if (isBirthday) {
    return (
      <View style={styles.container}>
        <LinearGradient
          colors={[BirthdayColors.softGold, BirthdayColors.cream, BirthdayColors.softGold]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={styles.birthdayCard}
        >
          {/* Decorative washi tape */}
          <View style={[styles.washiTape, styles.washiTapeTopLeft]} />
          <View style={[styles.washiTape, styles.washiTapeTopRight]} />
          <View style={[styles.washiTape, styles.washiTapeBottomLeft]} />
          <View style={[styles.washiTape, styles.washiTapeBottomRight]} />

          {/* Animated sparkles */}
          <Animated.Text
            style={[
              styles.sparkle,
              styles.sparkleTopLeft,
              {
                transform: [{ scale: sparkleScale }, { rotate: sparkleRotation }],
              },
            ]}
          >
            ✨
          </Animated.Text>
          <Animated.Text
            style={[
              styles.sparkle,
              styles.sparkleTopRight,
              {
                transform: [{ scale: sparkleScale }, { rotate: sparkleRotation }],
              },
            ]}
          >
            ✨
          </Animated.Text>
          <Animated.Text
            style={[
              styles.sparkle,
              styles.sparkleBottomLeft,
              {
                transform: [{ scale: sparkleScale }, { rotate: sparkleRotation }],
              },
            ]}
          >
            ⭐
          </Animated.Text>
          <Animated.Text
            style={[
              styles.sparkle,
              styles.sparkleBottomRight,
              {
                transform: [{ scale: sparkleScale }, { rotate: sparkleRotation }],
              },
            ]}
          >
            ⭐
          </Animated.Text>

          <View style={styles.birthdayContent}>
            <Text style={styles.birthdayEmoji}>🎂</Text>
            <Text style={styles.birthdayTitle}>Happy Birthday,</Text>
            <Text style={styles.birthdayName}>Divita!</Text>
            <Text style={styles.birthdayMessage}>Your special day is here! 💖</Text>
          </View>
        </LinearGradient>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.card}>
        {/* Paper texture overlay */}
        <View style={styles.paperTexture} />

        {/* Decorative washi tape */}
        <View style={[styles.washiTape, styles.washiTapeTopLeft]} />
        <View style={[styles.washiTape, styles.washiTapeTopRight]} />
        <View style={[styles.washiTape, styles.washiTapeBottomLeft]} />
        <View style={[styles.washiTape, styles.washiTapeBottomRight]} />

        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.headerEmoji}>🎂</Text>
          <Text style={styles.headerTitle}>Countdown to Divita&apos;s Birthday</Text>
          <Text style={styles.headerDate}>February 7th</Text>
        </View>

        {/* Countdown display */}
        <View style={styles.countdownContainer}>
          <TimeUnit value={timeLeft.days} label="Days" animValue={daysAnim} />
          <TimeUnit value={timeLeft.hours} label="Hours" animValue={hoursAnim} />
          <TimeUnit value={timeLeft.minutes} label="Minutes" animValue={minutesAnim} />
          <TimeUnit value={timeLeft.seconds} label="Seconds" animValue={secondsAnim} />
        </View>

        {/* Decorative hearts */}
        <View style={styles.heartsRow}>
          <Text style={styles.heartEmoji}>💖</Text>
          <Text style={styles.heartEmoji}>✨</Text>
          <Text style={styles.heartEmoji}>💖</Text>
        </View>
      </View>
    </View>
  );
}

interface TimeUnitProps {
  value: number;
  label: string;
  animValue: Animated.Value;
}

function TimeUnit({ value, label, animValue }: TimeUnitProps) {
  const scale = animValue.interpolate({
    inputRange: [0, 0.5, 1],
    outputRange: [1, 1.15, 1],
  });

  return (
    <View style={styles.timeUnit}>
      <View style={styles.timeValueContainer}>
        <Animated.Text style={[styles.timeValue, { transform: [{ scale }] }]}>
          {String(value).padStart(2, '0')}
        </Animated.Text>
      </View>
      <Text style={styles.timeLabel}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    width: SCREEN_WIDTH - 40,
    alignSelf: 'center',
    marginBottom: 24,
  },
  card: {
    backgroundColor: BirthdayColors.white,
    borderRadius: 24,
    padding: 24,
    ...BirthdayShadow,
    overflow: 'hidden',
  },
  paperTexture: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(255, 248, 240, 0.3)',
    opacity: 0.5,
  },
  washiTape: {
    position: 'absolute',
    width: 60,
    height: 20,
    borderRadius: 2,
    opacity: 0.7,
  },
  washiTapeTopLeft: {
    top: -5,
    left: 20,
    backgroundColor: BirthdayColors.blushPink,
    transform: [{ rotate: '-5deg' }],
  },
  washiTapeTopRight: {
    top: -5,
    right: 20,
    backgroundColor: BirthdayColors.softLavender,
    transform: [{ rotate: '5deg' }],
  },
  washiTapeBottomLeft: {
    bottom: -5,
    left: 30,
    backgroundColor: BirthdayColors.peach,
    transform: [{ rotate: '3deg' }],
  },
  washiTapeBottomRight: {
    bottom: -5,
    right: 30,
    backgroundColor: BirthdayColors.mintGreen,
    transform: [{ rotate: '-3deg' }],
  },
  header: {
    alignItems: 'center',
    marginBottom: 28,
  },
  headerEmoji: {
    fontSize: 48,
    marginBottom: 12,
  },
  headerTitle: {
    fontFamily: BirthdayFonts.handwritten,
    fontSize: 26,
    color: BirthdayColors.textDark,
    textAlign: 'center',
    marginBottom: 6,
  },
  headerDate: {
    fontFamily: BirthdayFonts.body,
    fontSize: 14,
    color: BirthdayColors.textMedium,
    letterSpacing: 1,
  },
  countdownContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  timeUnit: {
    alignItems: 'center',
    flex: 1,
  },
  timeValueContainer: {
    backgroundColor: BirthdayColors.softLavender,
    borderRadius: 16,
    paddingVertical: 16,
    paddingHorizontal: 12,
    minWidth: 65,
    marginBottom: 8,
    shadowColor: BirthdayColors.lavender,
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.2,
    shadowRadius: 6,
    elevation: 4,
  },
  timeValue: {
    fontFamily: BirthdayFonts.bodyBold,
    fontSize: 32,
    color: BirthdayColors.textDark,
    textAlign: 'center',
  },
  timeLabel: {
    fontFamily: BirthdayFonts.bodyMedium,
    fontSize: 11,
    color: BirthdayColors.textMedium,
    textAlign: 'center',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  heartsRow: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 12,
    marginTop: 8,
  },
  heartEmoji: {
    fontSize: 24,
  },
  birthdayCard: {
    borderRadius: 24,
    padding: 32,
    ...BirthdayShadow,
    overflow: 'hidden',
    minHeight: 280,
    justifyContent: 'center',
  },
  birthdayContent: {
    alignItems: 'center',
  },
  birthdayEmoji: {
    fontSize: 64,
    marginBottom: 16,
  },
  birthdayTitle: {
    fontFamily: BirthdayFonts.elegant,
    fontSize: 28,
    color: BirthdayColors.textDark,
    marginBottom: 4,
  },
  birthdayName: {
    fontFamily: BirthdayFonts.script,
    fontSize: 52,
    color: BirthdayColors.gold,
    marginBottom: 16,
    textShadowColor: 'rgba(212, 165, 116, 0.3)',
    textShadowOffset: { width: 0, height: 2 },
    textShadowRadius: 4,
  },
  birthdayMessage: {
    fontFamily: BirthdayFonts.handwrittenRegular,
    fontSize: 18,
    color: BirthdayColors.textMedium,
    textAlign: 'center',
  },
  sparkle: {
    position: 'absolute',
    fontSize: 28,
  },
  sparkleTopLeft: {
    top: 20,
    left: 20,
  },
  sparkleTopRight: {
    top: 20,
    right: 20,
  },
  sparkleBottomLeft: {
    bottom: 30,
    left: 30,
  },
  sparkleBottomRight: {
    bottom: 30,
    right: 30,
  },
});
