import React, { useEffect, useRef } from 'react';
import { Animated, Dimensions, StyleSheet, View } from 'react-native';

import { BirthdayColors } from '@/constants/birthday-theme';

const { width: SCREEN_WIDTH, height: SCREEN_HEIGHT } = Dimensions.get('window');

const CONFETTI_COLORS = [
  BirthdayColors.confettiPink,
  BirthdayColors.confettiGold,
  BirthdayColors.confettiLavender,
  BirthdayColors.confettiPeach,
  BirthdayColors.deepPink,
  BirthdayColors.blushPink,
  BirthdayColors.babyBlue,
  BirthdayColors.mintGreen,
];

interface ConfettiPieceConfig {
  color: string;
  width: number;
  height: number;
  startX: number;
  startRotation: number;
  endRotation: number;
  duration: number;
  delay: number;
  swayAmplitude: number;
  borderRadius: number;
}

function generateConfetti(count: number): ConfettiPieceConfig[] {
  const pieces: ConfettiPieceConfig[] = [];
  for (let i = 0; i < count; i++) {
    const isSquare = Math.random() > 0.5;
    const size = 6 + Math.random() * 8;
    pieces.push({
      color: CONFETTI_COLORS[i % CONFETTI_COLORS.length],
      width: isSquare ? size : size * 0.5,
      height: isSquare ? size : size * 1.5,
      startX: Math.random() * SCREEN_WIDTH,
      startRotation: Math.random() * 360,
      endRotation: Math.random() * 360 + 360,
      duration: 3000 + Math.random() * 3000,
      delay: Math.random() * 2000,
      swayAmplitude: 30 + Math.random() * 60,
      borderRadius: Math.random() > 0.6 ? size / 2 : 2,
    });
  }
  return pieces;
}

interface ConfettiPieceProps {
  config: ConfettiPieceConfig;
}

function ConfettiPiece({ config }: ConfettiPieceProps) {
  const animatedValue = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    const animation = Animated.loop(
      Animated.sequence([
        Animated.delay(config.delay),
        Animated.timing(animatedValue, {
          toValue: 1,
          duration: config.duration,
          useNativeDriver: true,
        }),
      ]),
    );

    animation.start();

    return () => {
      animation.stop();
    };
  }, [animatedValue, config.delay, config.duration]);

  const translateY = animatedValue.interpolate({
    inputRange: [0, 1],
    outputRange: [-50, SCREEN_HEIGHT + 50],
  });

  const translateX = animatedValue.interpolate({
    inputRange: [0, 0.25, 0.5, 0.75, 1],
    outputRange: [
      0,
      config.swayAmplitude,
      0,
      -config.swayAmplitude,
      0,
    ],
  });

  const rotate = animatedValue.interpolate({
    inputRange: [0, 1],
    outputRange: [`${config.startRotation}deg`, `${config.endRotation}deg`],
  });

  const opacity = animatedValue.interpolate({
    inputRange: [0, 0.05, 0.85, 1],
    outputRange: [0, 0.9, 0.9, 0],
  });

  return (
    <Animated.View
      style={[
        styles.piece,
        {
          left: config.startX,
          width: config.width,
          height: config.height,
          backgroundColor: config.color,
          borderRadius: config.borderRadius,
          transform: [{ translateY }, { translateX }, { rotate }],
          opacity,
        },
      ]}
    />
  );
}

interface ConfettiAnimationProps {
  count?: number;
}

export default function ConfettiAnimation({ count = 30 }: ConfettiAnimationProps) {
  const confetti = useRef(generateConfetti(count)).current;

  return (
    <View style={styles.container} pointerEvents="none">
      {confetti.map((config, index) => (
        <ConfettiPiece key={index} config={config} />
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    ...StyleSheet.absoluteFillObject,
    overflow: 'hidden',
  },
  piece: {
    position: 'absolute',
    top: 0,
  },
});
