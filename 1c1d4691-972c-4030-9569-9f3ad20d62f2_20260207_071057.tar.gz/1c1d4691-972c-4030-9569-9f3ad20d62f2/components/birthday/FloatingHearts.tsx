import React, { useEffect, useRef } from 'react';
import { Animated, Dimensions, StyleSheet, View } from 'react-native';

const { width: SCREEN_WIDTH, height: SCREEN_HEIGHT } = Dimensions.get('window');

const HEART_EMOJIS = ['\u2764\uFE0F', '\uD83D\uDC96', '\uD83D\uDC95', '\uD83D\uDC97', '\uD83E\uDE77'];

interface HeartConfig {
  emoji: string;
  size: number;
  startX: number;
  duration: number;
  delay: number;
  rotation: number;
  opacity: number;
  swayAmplitude: number;
}

function generateHearts(count: number): HeartConfig[] {
  const hearts: HeartConfig[] = [];
  for (let i = 0; i < count; i++) {
    hearts.push({
      emoji: HEART_EMOJIS[i % HEART_EMOJIS.length],
      size: 16 + Math.random() * 20,
      startX: Math.random() * SCREEN_WIDTH,
      duration: 4000 + Math.random() * 4000,
      delay: Math.random() * 3000,
      rotation: -30 + Math.random() * 60,
      opacity: 0.3 + Math.random() * 0.5,
      swayAmplitude: 20 + Math.random() * 40,
    });
  }
  return hearts;
}

interface FloatingHeartProps {
  config: HeartConfig;
}

function FloatingHeart({ config }: FloatingHeartProps) {
  const animatedValue = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    const startAnimation = () => {
      animatedValue.setValue(0);
      Animated.loop(
        Animated.sequence([
          Animated.delay(config.delay),
          Animated.timing(animatedValue, {
            toValue: 1,
            duration: config.duration,
            useNativeDriver: true,
          }),
        ]),
      ).start();
    };

    startAnimation();
  }, [animatedValue, config.delay, config.duration]);

  const translateY = animatedValue.interpolate({
    inputRange: [0, 1],
    outputRange: [SCREEN_HEIGHT + 50, -100],
  });

  const translateX = animatedValue.interpolate({
    inputRange: [0, 0.25, 0.5, 0.75, 1],
    outputRange: [
      0,
      config.swayAmplitude,
      0,
      -config.swayAmplitude,
      0,
    ],
  });

  const opacity = animatedValue.interpolate({
    inputRange: [0, 0.1, 0.8, 1],
    outputRange: [0, config.opacity, config.opacity, 0],
  });

  const rotate = animatedValue.interpolate({
    inputRange: [0, 1],
    outputRange: [`${config.rotation}deg`, `${config.rotation + 20}deg`],
  });

  return (
    <Animated.Text
      style={[
        styles.heart,
        {
          left: config.startX,
          fontSize: config.size,
          transform: [{ translateY }, { translateX }, { rotate }],
          opacity,
        },
      ]}
    >
      {config.emoji}
    </Animated.Text>
  );
}

export default function FloatingHearts() {
  const hearts = useRef(generateHearts(15)).current;

  return (
    <View style={styles.container} pointerEvents="none">
      {hearts.map((config, index) => (
        <FloatingHeart key={index} config={config} />
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    ...StyleSheet.absoluteFillObject,
    overflow: 'hidden',
  },
  heart: {
    position: 'absolute',
    bottom: 0,
  },
});
