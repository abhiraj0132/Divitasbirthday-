import React from 'react';
import {
  Image,
  ImageSourcePropType,
  StyleProp,
  StyleSheet,
  Text,
  View,
  ViewStyle,
} from 'react-native';

import {
  BirthdayColors,
  BirthdayFonts,
  WashiTapeColors,
} from '@/constants/birthday-theme';

interface PolaroidFrameProps {
  source: ImageSourcePropType;
  caption?: string;
  rotation?: number;
  washiTapeColor?: string;
  style?: StyleProp<ViewStyle>;
}

export default function PolaroidFrame({
  source,
  caption,
  rotation = 0,
  washiTapeColor,
  style,
}: PolaroidFrameProps) {
  const tapeColor =
    washiTapeColor ??
    WashiTapeColors[Math.floor(Math.random() * WashiTapeColors.length)];

  return (
    <View
      style={[
        styles.container,
        { transform: [{ rotate: `${rotation}deg` }] },
        style,
      ]}
    >
      {/* Washi tape decoration */}
      <View style={styles.washiTapeWrapper}>
        <View style={[styles.washiTape, { backgroundColor: tapeColor }]} />
      </View>

      {/* Polaroid frame */}
      <View style={styles.frame}>
        <View style={styles.imageContainer}>
          <Image source={source} style={styles.image} resizeMode="cover" />
        </View>

        {caption ? (
          <View style={styles.captionContainer}>
            <Text style={styles.captionText} numberOfLines={2}>
              {caption}
            </Text>
          </View>
        ) : (
          <View style={styles.captionSpacer} />
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
  },
  washiTapeWrapper: {
    zIndex: 1,
    alignItems: 'center',
    marginBottom: -8,
  },
  washiTape: {
    width: 60,
    height: 16,
    opacity: 0.7,
    borderRadius: 2,
  },
  frame: {
    backgroundColor: BirthdayColors.white,
    padding: 10,
    paddingBottom: 40,
    shadowColor: BirthdayColors.roseGold,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 5,
  },
  imageContainer: {
    overflow: 'hidden',
  },
  image: {
    width: 200,
    height: 200,
  },
  captionContainer: {
    marginTop: 8,
    alignItems: 'center',
    paddingHorizontal: 4,
  },
  captionText: {
    fontFamily: BirthdayFonts.handwrittenRegular,
    fontSize: 16,
    color: BirthdayColors.textDark,
    textAlign: 'center',
  },
  captionSpacer: {
    height: 10,
  },
});
