import React from 'react';
import { StyleProp, StyleSheet, Text, View, ViewStyle } from 'react-native';

import { BirthdayColors, BirthdayFonts } from '@/constants/birthday-theme';

interface SectionTitleProps {
  title: string;
  subtitle?: string;
  emoji?: string;
  style?: StyleProp<ViewStyle>;
}

export default function SectionTitle({
  title,
  subtitle,
  emoji = '\u2728',
  style,
}: SectionTitleProps) {
  return (
    <View style={[styles.container, style]}>
      <View style={styles.titleRow}>
        <Text style={styles.decoration}>{emoji}</Text>
        <Text style={styles.title}>{title}</Text>
        <Text style={styles.decoration}>{emoji}</Text>
      </View>

      {subtitle ? (
        <Text style={styles.subtitle}>{subtitle}</Text>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    paddingVertical: 16,
    paddingHorizontal: 20,
  },
  titleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  decoration: {
    fontSize: 20,
  },
  title: {
    fontFamily: BirthdayFonts.handwritten,
    fontSize: 32,
    color: BirthdayColors.textDark,
    textAlign: 'center',
  },
  subtitle: {
    fontFamily: BirthdayFonts.body,
    fontSize: 14,
    color: BirthdayColors.textMedium,
    textAlign: 'center',
    marginTop: 6,
  },
});
