import { LinearGradient } from 'expo-linear-gradient';
import React from 'react';
import { ColorValue, StyleProp, StyleSheet, ViewStyle } from 'react-native';

import { BirthdayColors } from '@/constants/birthday-theme';

type GradientColors = readonly [ColorValue, ColorValue, ...ColorValue[]];

const DEFAULT_COLORS: GradientColors = [
  BirthdayColors.gradientStart,
  BirthdayColors.gradientMiddle,
  BirthdayColors.gradientEnd,
];

interface GradientBackgroundProps {
  colors?: GradientColors;
  start?: { x: number; y: number };
  end?: { x: number; y: number };
  style?: StyleProp<ViewStyle>;
  children?: React.ReactNode;
}

export default function GradientBackground({
  colors = DEFAULT_COLORS,
  start = { x: 0, y: 0 },
  end = { x: 1, y: 1 },
  style,
  children,
}: GradientBackgroundProps) {
  return (
    <LinearGradient
      colors={colors}
      start={start}
      end={end}
      style={[styles.gradient, style]}
    >
      {children}
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  gradient: {
    flex: 1,
  },
});
