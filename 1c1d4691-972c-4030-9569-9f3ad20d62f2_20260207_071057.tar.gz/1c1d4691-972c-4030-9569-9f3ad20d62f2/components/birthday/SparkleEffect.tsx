import React, { useEffect, useRef } from 'react';
import { Animated, Dimensions, StyleSheet, View } from 'react-native';

const { width: SCREEN_WIDTH, height: SCREEN_HEIGHT } = Dimensions.get('window');

const SPARKLE_EMOJIS = ['\u2728', '\u2B50'];

interface SparkleConfig {
  emoji: string;
  size: number;
  x: number;
  y: number;
  duration: number;
  delay: number;
}

function generateSparkles(count: number): SparkleConfig[] {
  const sparkles: SparkleConfig[] = [];
  for (let i = 0; i < count; i++) {
    sparkles.push({
      emoji: SPARKLE_EMOJIS[i % SPARKLE_EMOJIS.length],
      size: 10 + Math.random() * 14,
      x: Math.random() * (SCREEN_WIDTH - 30),
      y: Math.random() * (SCREEN_HEIGHT - 30),
      duration: 1500 + Math.random() * 2000,
      delay: Math.random() * 2500,
    });
  }
  return sparkles;
}

interface SparkleItemProps {
  config: SparkleConfig;
}

function SparkleItem({ config }: SparkleItemProps) {
  const opacity = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    const animation = Animated.loop(
      Animated.sequence([
        Animated.delay(config.delay),
        Animated.timing(opacity, {
          toValue: 1,
          duration: config.duration / 2,
          useNativeDriver: true,
        }),
        Animated.timing(opacity, {
          toValue: 0,
          duration: config.duration / 2,
          useNativeDriver: true,
        }),
      ]),
    );

    animation.start();

    return () => {
      animation.stop();
    };
  }, [opacity, config.delay, config.duration]);

  return (
    <Animated.Text
      style={[
        styles.sparkle,
        {
          left: config.x,
          top: config.y,
          fontSize: config.size,
          opacity,
        },
      ]}
    >
      {config.emoji}
    </Animated.Text>
  );
}

interface SparkleEffectProps {
  count?: number;
}

export default function SparkleEffect({ count = 20 }: SparkleEffectProps) {
  const sparkles = useRef(generateSparkles(count)).current;

  return (
    <View style={styles.container} pointerEvents="none">
      {sparkles.map((config, index) => (
        <SparkleItem key={index} config={config} />
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    ...StyleSheet.absoluteFillObject,
    overflow: 'hidden',
  },
  sparkle: {
    position: 'absolute',
  },
});
