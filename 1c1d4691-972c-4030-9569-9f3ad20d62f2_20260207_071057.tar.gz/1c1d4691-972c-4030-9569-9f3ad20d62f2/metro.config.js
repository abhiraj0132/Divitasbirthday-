const { getDefaultConfig } = require('expo/metro-config');
const path = require('path');

const config = getDefaultConfig(__dirname);

// Determine if we're in production mode
const isProduction = process.env.NODE_ENV === 'production';

// Configure minification based on environment
config.transformer = {
  ...config.transformer,
  minifierConfig: {
    compress: {
      // Drop console.log in production builds
      drop_console: isProduction,
    },
    mangle: isProduction,
    output: {
      comments: !isProduction,
    },
  },
  // Enable inline requires for better performance
  inlineRequires: true,
};

// Add support for resolving modules and assets
config.resolver = {
  ...config.resolver,
  nodeModulesPaths: [
    path.resolve(__dirname, 'node_modules'),
    path.resolve(__dirname),
  ],
  // Support for images and fonts
  assetExts: [
    ...(config.resolver.assetExts || []),
    'jpg',
    'jpeg',
    'png',
    'gif',
    'webp',
    'svg',
    'ttf',
    'otf',
    'woff',
    'woff2',
  ],
  sourceExts: [
    ...(config.resolver.sourceExts || []),
    'jsx',
    'js',
    'ts',
    'tsx',
    'json',
  ],
  resolverMainFields: ['react-native', 'browser', 'main'],
};

// Configure Metro for proxy deployment (web)
config.server = {
  ...config.server,
  enhanceMiddleware: (middleware) => {
    return (req, res, next) => {
      // Check if we're being accessed through the proxy
      const proxyPath = req.headers['x-forwarded-prefix'];
      if (proxyPath) {
        // Inject base path into the HTML
        const originalSend = res.send;
        res.send = function(data) {
          if (typeof data === 'string' && data.includes('<head>')) {
            // Add base tag to make all relative URLs work
            data = data.replace(
              '<head>',
              `<head><base href="${proxyPath}/">`
            );
          }
          originalSend.call(this, data);
        };
      }
      return middleware(req, res, next);
    };
  },
};

module.exports = config;
