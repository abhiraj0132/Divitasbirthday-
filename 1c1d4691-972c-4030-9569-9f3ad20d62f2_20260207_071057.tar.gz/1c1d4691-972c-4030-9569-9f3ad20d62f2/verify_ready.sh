#!/bin/bash
echo "🔍 Verifying Production Readiness..."
echo ""

# Check TypeScript
echo "1️⃣  Checking TypeScript..."
npx tsc --noEmit 2>&1 | head -5
if [ $? -eq 0 ]; then
  echo "✅ TypeScript: PASSED"
else
  echo "❌ TypeScript: FAILED"
fi
echo ""

# Check photos
echo "2️⃣  Checking Photos..."
total_size=$(du -sc assets/images/divita/*.jpg | tail -1 | cut -f1)
if [ "$total_size" -gt 10000 ]; then
  echo "✅ Photos: Real images detected (${total_size}K total)"
else
  echo "⚠️  Photos: Still placeholders (only ${total_size}K total)"
  echo "   → Please replace with actual photos before building!"
fi
echo ""

# Check EAS config
echo "3️⃣  Checking EAS Configuration..."
if [ -f "eas.json" ]; then
  echo "✅ EAS Config: Found"
else
  echo "❌ EAS Config: Missing"
fi
echo ""

# Check fonts
echo "4️⃣  Checking Fonts..."
font_count=$(find node_modules/@expo-google-fonts -name "*.ttf" 2>/dev/null | wc -l)
if [ "$font_count" -gt 0 ]; then
  echo "✅ Fonts: $font_count fonts found"
else
  echo "⚠️  Fonts: Not found (may need npm install)"
fi
echo ""

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "📋 PRODUCTION STATUS:"
echo ""
if [ "$total_size" -gt 10000 ]; then
  echo "✅ App is PRODUCTION-READY!"
  echo ""
  echo "Next steps:"
  echo "  1. Login: npx eas-cli login"
  echo "  2. Build: npx eas-cli build --platform android --profile preview"
  echo "  3. Share link with Divita!"
else
  echo "⚠️  Almost ready! Just add real photos:"
  echo ""
  echo "Next steps:"
  echo "  1. Replace placeholder photos in assets/images/divita/"
  echo "  2. Re-run this script to verify"
  echo "  3. Then build with: npx eas-cli build --platform android --profile preview"
fi
echo ""
