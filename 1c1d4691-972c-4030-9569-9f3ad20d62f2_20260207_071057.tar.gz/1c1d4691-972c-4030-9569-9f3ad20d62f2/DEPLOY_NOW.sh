#!/bin/bash

# 🎁 One-Command Deployment for Divita's Birthday Bloom
# Usage: ./DEPLOY_NOW.sh [android|web]

set -e

echo "🎉 Divita's Birthday Bloom - Deployment Script"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

# Check which platform
PLATFORM="${1:-android}"

if [ "$PLATFORM" = "android" ]; then
  echo "📱 Deploying Android APK..."
  echo ""
  echo "Step 1: Verifying EAS login..."

  if npx eas-cli whoami > /dev/null 2>&1; then
    echo "✅ Logged in as: $(npx eas-cli whoami)"
  else
    echo "⚠️  Not logged in. Logging in now..."
    npx eas-cli login
  fi

  echo ""
  echo "Step 2: Starting Android build..."
  echo "⏱️  This will take approximately 10-15 minutes"
  echo ""

  npx eas-cli build --platform android --profile preview

  echo ""
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo "✅ Build submitted successfully!"
  echo ""
  echo "📧 You'll receive an email when the build is complete"
  echo "🔗 Download link will be provided"
  echo ""
  echo "Share the link with Divita using the message template in:"
  echo "   🎁_FINAL_HANDOVER_FOR_ABHIRAJ.md"
  echo ""

elif [ "$PLATFORM" = "web" ]; then
  echo "🌐 Deploying Web App..."
  echo ""

  # Check if dist/web exists
  if [ ! -d "dist/web" ]; then
    echo "Step 1: Building web version..."
    npx expo export --platform web --output-dir dist/web --clear
  else
    echo "✅ Web build already exists (dist/web)"
  fi

  echo ""
  echo "Step 2: Choose deployment method:"
  echo ""
  echo "Option A - Netlify (recommended):"
  echo "  cd dist/web && netlify deploy --prod"
  echo ""
  echo "Option B - Vercel:"
  echo "  cd dist/web && vercel --prod"
  echo ""
  echo "Option C - Firebase:"
  echo "  cd dist/web && firebase deploy"
  echo ""
  echo "Run one of the above commands to deploy!"
  echo ""

else
  echo "❌ Invalid platform: $PLATFORM"
  echo ""
  echo "Usage:"
  echo "  ./DEPLOY_NOW.sh android    # Build Android APK"
  echo "  ./DEPLOY_NOW.sh web        # Deploy web version"
  echo ""
  exit 1
fi

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "🎁 Happy deploying! Divita will love it! ✨"
