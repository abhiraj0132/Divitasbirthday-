#!/bin/bash

# 🎁 Divita's Birthday Bloom - One-Command Deployment
# This script deploys the web version instantly

set -e

echo "╔══════════════════════════════════════════════════════════╗"
echo "║  🎉 DIVITA'S BIRTHDAY BLOOM - QUICK DEPLOY 🎉           ║"
echo "╚══════════════════════════════════════════════════════════╝"
echo ""

# Check if photos have been replaced
PHOTO_SIZE=$(stat -f%z assets/images/divita/photo1.jpg 2>/dev/null || stat -c%s assets/images/divita/photo1.jpg 2>/dev/null)

if [ "$PHOTO_SIZE" -lt 1000 ]; then
    echo "⚠️  WARNING: Photos are still placeholders (${PHOTO_SIZE} bytes)"
    echo ""
    echo "Please replace the 9 placeholder photos with real photos first:"
    echo "  📁 Location: assets/images/divita/photo1.jpg through photo9.jpg"
    echo ""
    echo "Once photos are added, run this script again!"
    echo ""
    read -p "Continue anyway? (y/N): " -n 1 -r
    echo ""
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
fi

echo "📦 Step 1/3: Rebuilding web version with your photos..."
npx expo export --platform web

echo ""
echo "✅ Web build complete!"
echo ""
echo "🚀 Step 2/3: Choose deployment method:"
echo "  1) Vercel (recommended)"
echo "  2) Netlify"
echo "  3) Surge"
echo ""
read -p "Enter choice (1-3): " choice

case $choice in
    1)
        echo ""
        echo "🌐 Deploying to Vercel..."
        npx vercel dist-web --prod
        ;;
    2)
        echo ""
        echo "🌐 Deploying to Netlify..."
        npx netlify-cli deploy --dir=dist-web --prod
        ;;
    3)
        echo ""
        echo "🌐 Deploying to Surge..."
        npm install -g surge
        cd dist-web
        surge . divitas-birthday-bloom.surge.sh
        cd ..
        ;;
    *)
        echo "Invalid choice. Defaulting to Vercel..."
        npx vercel dist-web --prod
        ;;
esac

echo ""
echo "╔══════════════════════════════════════════════════════════╗"
echo "║  ✨ WEB VERSION DEPLOYED SUCCESSFULLY! ✨                ║"
echo "╚══════════════════════════════════════════════════════════╝"
echo ""
echo "📱 Next step: Build Android APK (optional)"
echo ""
echo "To build the Android APK, run:"
echo "  npx eas-cli login"
echo "  npx eas-cli build --platform android --profile production"
echo ""
echo "Made with 💖 for Divita's Birthday"
echo "From Abhiraj"
echo ""
